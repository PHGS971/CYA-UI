-- CYA UI Script Inicial
loadstring(game:HttpGet("https://raw.githubusercontent.com/PHGS971/CYAUI/main/src/init.lua"))()
